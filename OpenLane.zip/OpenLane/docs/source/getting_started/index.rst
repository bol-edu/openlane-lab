Getting Started
----------------------

.. toctree::
   :glob:


   installation
   installation_local
   quickstart