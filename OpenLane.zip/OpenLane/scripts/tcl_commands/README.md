# OpenLane Package
-------------------

## Commands

Refer to this [README](../../docs/source/openlane_commands.md)

** All .tcl files placed here should `provide openlane`; otherwise, they won't
be available in the flow.
